package Academia_ex7;

/*
  7. Crie uma classe para representar um cliente de uma academia.
 Defina 4 possíveis atributos e implemente os métodos getters e setters.
 Criar o JFrame com os campos definidos, e ao clicar no botão deve setar os dados no objeto de cliente.
 */

public class Cliente {
    private String nome;
    private String cpf;
    private String endereco;
    private String telefone;
    private double peso;
    private double altura;
    
    public void setNome(String n){
        this.nome = n;
    }
    public String getNome(){
        return nome;
    }
    
    public void setCPF(String c){
        this.cpf = c;
    }
    public String getCPF(){
        return cpf;
    }
    
    public void setEndereco(String e){
        this.endereco = e;
    }
    public String getEndereco(){
        return endereco;
    }
    
    public void setTelefone(String t){
        this.telefone = t;
    }
    public String getTelefone(){
        return telefone;
    }
    
    public void setPeso(double p){
        this.peso = p;
    }
    public double getPeso(){
        return peso;
    }
    
    public void setAltura(double a){
        this.altura = a;
    }
    public double getAltura(){
        return altura;
    }
}

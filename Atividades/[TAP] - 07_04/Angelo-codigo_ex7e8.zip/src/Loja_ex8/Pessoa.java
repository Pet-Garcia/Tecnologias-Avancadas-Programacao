
package Loja_ex8;

public class Pessoa {
    private String nome;
    private int idade;
    private String sexo;
    
    public void setNome(String n){
        this.nome = n;
    }
    public String getNome(){
        return nome;
    }
    
    public void setIdade(int i){
        this.idade = i;
    }
    public int getIdade(){
        return idade;
    }
    
    public void setSexo(String s){
        this.sexo = s;
    }
    public String getSexo(){
        return sexo;
    }
}

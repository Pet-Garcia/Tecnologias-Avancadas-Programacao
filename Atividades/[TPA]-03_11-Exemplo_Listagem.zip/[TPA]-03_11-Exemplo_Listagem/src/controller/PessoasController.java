/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import model.PessoasModelo;
import vo.Pessoa;

/**
 *
 * @author aluno
 */
public class PessoasController {
    public ArrayList<Pessoa> buscarDados() {
        PessoasModelo pm = new PessoasModelo();
        return pm.buscarDados();
    }
}

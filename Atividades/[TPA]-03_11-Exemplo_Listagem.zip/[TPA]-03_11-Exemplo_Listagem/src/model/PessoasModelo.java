
package model;

import com.sun.jdi.connect.spi.Connection;
import connection.Conexao;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import vo.Pessoa;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PessoasModelo {
    
    public ArrayList<Pessoa> buscarDadosBD() {
        PreparedStatement ps;
        ResultSet rs;
        try {
            Connection con = new Conexao().conectar();
            if (con != null) {
                String comando = "SELECT id,solicitante,solicitacao FROM solicitacoes";
                ps = con.prepareStatement(comando);
                // efetua a busca e armazena na variável rs
                rs = ps.executeQuery();
                ArrayList<Pessoa> listaResultados = new ArrayList<>();
                
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String nome = rs.getString("nome");
                    Double salario = rs.getDouble("salario");
                    Pessoa p = new Pessoa();
                    p.setId(id);
                    p.setNome(nome);
                    p.setSalario(salario);
                    listaResultados.add(p);
                }
                return listaResultados;
 
            } else {
                JOptionPane.showMessageDialog(rootPane, "Erro ao buscar");
                return null;
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(rootPane, "Erro: " + erro);
        }
        return null;
    }
}

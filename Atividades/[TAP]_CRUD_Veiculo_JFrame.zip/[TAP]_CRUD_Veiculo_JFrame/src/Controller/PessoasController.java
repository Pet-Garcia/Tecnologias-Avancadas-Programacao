/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.PessoasModelo;
import VO.Pessoa;
import java.util.ArrayList;

/**
 *
 * @author Jean
 */
public class PessoasController {
    
    public ArrayList<Pessoa> buscarDados(){
        PessoasModelo pm = new PessoasModelo();        
        return pm.buscarDadosBD();
    }
}


package Controller;

import java.sql.SQLException;
import VO.Veiculo;
import Model.VeiculoModelo;
import Model.VeiculoModelo;
import java.util.ArrayList;

public class VeiculoController {
    
    VeiculoModelo vm = new VeiculoModelo();
    public ArrayList<Veiculo> buscarDados(){
        VeiculoModelo pm = new VeiculoModelo();        
        return pm.buscarDadosBD();
    }
    
    public boolean efetuaGravacao(String modelo, String marca, String placa, String cor, int ano) throws SQLException {
        return vm.efetuaGravacao(modelo, marca, placa, cor, ano);
    }
    
}


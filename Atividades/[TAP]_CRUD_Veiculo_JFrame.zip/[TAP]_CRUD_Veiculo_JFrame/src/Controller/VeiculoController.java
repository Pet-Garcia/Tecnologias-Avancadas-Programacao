
package Controller;

import java.sql.SQLException;
import VO.Veiculo;
import Model.VeiculoModelo;
import Model.VeiculoModelo;
import java.util.ArrayList;

public class VeiculoController {
    
    VeiculoModelo vm = new VeiculoModelo();
    public ArrayList<Veiculo> buscarDados(){
        VeiculoModelo pm = new VeiculoModelo();        
        return pm.buscarDadosBD();
    }
    
    public boolean efetuaGravacao(modelo, marca, placa, cor, ano) {
        return vc.efetuaGravacao(modelo, marca, placa, cor, ano);
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Connection.Conexao;
import VO.Veiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author aluno
 */
public class VeiculoModelo {
    
    public ArrayList<Veiculo> buscarDadosBD() {
        PreparedStatement ps;
        ResultSet rs;
        try {
            Connection con = new Conexao().ConexaoBD();
            String comando = "SELECT id,nome,salario FROM pessoas";
            ps = con.prepareStatement(comando);
            rs = ps.executeQuery();
            ArrayList<Veiculo> listaResultados = new ArrayList<>();
            while (rs.next()) {
                int id = rs.getInt("id");
                String modelo = rs.getString("modelo");
                String marca = rs.getString("marca");
                String placa = rs.getString("placa");
                String cor = rs.getString("cor");
                int ano = rs.getInt("ano");
                Veiculo v = new Veiculo();
                v.setId(id);
                v.setModelo(modelo);
                v.setMarca(marca);
                v.setPlaca(placa);
                v.setCor(cor);
                v.setAno(ano);
                // Colocar o restante
                listaResultados.add(v);
            }
            return listaResultados;
        } catch (SQLException erro) {
            System.out.println("Erro ao efetuar a busca");
            return null;
        }

    }
    
    public boolean efetuaGravacao(String modelo, String marca, String placa, String cor, int ano) throws SQLException{
        
        Veiculo v = new Veiculo();
        
        v.setModelo(modelo);
        v.setMarca(marca);
        v.setPlaca(placa);
        v.setCor(cor);
        v.setAno(ano);
        
        return v.gravar(modelo, marca, placa, cor, ano);
    }
}

package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    private final String bd = "jdbc:mysql://localhost/veiculos";
    private final String usuario = "root"; // Para não precisar configurar um usuário no bd coloquei como root para o exercicio
    private final String senha = "";

    
    public Connection ConexaoBD() throws SQLException{
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(bd, usuario, senha);//Nessa exata ordem
        } catch (ClassNotFoundException | SQLException erro) {
            System.out.println("Erro na conexão: " + erro);
            return null;
        }
    }
}


package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Veiculo {
    
    private String modelo;
    private String marca;
    private String placa;
    private String cor;
    private int ano;

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
    
    // Função de Cadastro
    public boolean gravar(String modelo, String marca, String placa, String cor, int ano) throws SQLException{
        
        try{
            // Conexão
            Connection con = new Conexao().ConexaoBD();
            if (con != null){
                PreparedStatement ps;
                // Modelo que vai ser inserido os valores
                String sql = "insert into veiculos (modelo, marca, placa,cor, ano) values (?, ?, ?, ?, ?)";
                ps = con.prepareStatement(sql);
                // Valores
                ps.setString(1, modelo);
                ps.setString(2, marca);
                ps.setString(3, placa);
                ps.setString(4, cor);
                ps.setInt(5, ano);
                // Executa o comando no sql
                ps.executeUpdate();
                
                ps.close();
                con.close();
            } 
        }catch(SQLException erro){
                System.out.println("Exceção causada na inserção");
        }
        return true;
    }
    
    // Listar os valores do sql no jframe
    public ArrayList<Veiculo> listar() throws SQLException {
        ArrayList<Veiculo> lista = new ArrayList<>();

        // Conexão
        Connection con = new Conexao().ConexaoBD();

        // Modelo
        String sql = "SELECT modelo, marca, placa, cor, ano FROM veiculos";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            // Enquanto houver linhas continua funcionando
            while (rs.next()) {
                Veiculo v = new Veiculo();

                // Pegando os modelos e colocando como atuais
                v.setModelo(rs.getString("modelo"));
                v.setMarca(rs.getString("marca"));
                v.setPlaca(rs.getString("placa"));
                v.setCor(rs.getString("cor"));
                v.setAno(rs.getInt("ano"));

                // Adiciona na tabela
                lista.add(v);
            }
        } finally {
            if (con != null) {
                con.close();
            }
        }

        return lista;
    }
}

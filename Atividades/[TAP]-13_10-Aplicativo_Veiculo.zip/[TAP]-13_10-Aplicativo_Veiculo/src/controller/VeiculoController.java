
package controller;

import java.sql.SQLException;
import model.Veiculo;

public class VeiculoController {
    
    public boolean efetuaGravacao(String modelo, String marca, String placa, String cor, int ano) throws SQLException{
        
        Veiculo v = new Veiculo();
        
        v.setModelo(modelo);
        v.setMarca(marca);
        v.setPlaca(placa);
        v.setCor(cor);
        v.setAno(ano);
        
        return v.gravar(modelo, marca, placa, cor, ano);
    }
}

